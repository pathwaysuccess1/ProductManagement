package model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import utils.ConnectDB;

public class SessionDAO {

    private Connection con;

    public SessionDAO() throws ClassNotFoundException, SQLException {
        ConnectDB connectDB = new ConnectDB();
        con = connectDB.getConnection();
    }

    // Lưu sessionId của account
    public void saveAccountSession(String account, String sessionId) throws SQLException {
        String deleteSql = "DELETE FROM account_sessions WHERE accounts = ?";
        String insertSql = "INSERT INTO account_sessions (account, session_id, login_time) VALUES (?, ?, GETDATE())";

        try (PreparedStatement deletePs = con.prepareStatement(deleteSql)) {
            deletePs.setString(1, account);
            deletePs.executeUpdate();
        }

        try (PreparedStatement insertPs = con.prepareStatement(insertSql)) {
            insertPs.setString(1, account);
            insertPs.setString(2, sessionId);
            insertPs.executeUpdate();
        }
    }

    // Lấy sessionId đang active của account
    public String getActiveSession(String account) throws SQLException {
        String sql = "SELECT session_id FROM account_sessions WHERE accounts = ?";
        try (PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, account);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return rs.getString("session_id");
                }
            }
        }
        return null;
    }

    // Xóa session khi account logout
    public void removeAccountSession(String account) throws SQLException {
        String sql = "DELETE FROM account_sessions WHERE accounts = ?";
        try (PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, account);
            ps.executeUpdate();
        }
    }

    // Đóng kết nối khi không còn dùng nữa
    public void close() throws SQLException {
        if (con != null && !con.isClosed()) {
            con.close();
        }
    }
}
