/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.ServletContext;
import utils.ConnectDB;

/**
 *
 * @author USER
 */
public class ProductDAO implements Accessible<Product> {

    private ServletContext sc;
    private Connection con;

    public ProductDAO() throws ClassNotFoundException, SQLException {
        ConnectDB connectDB = new ConnectDB();
        con = connectDB.getConnection();
    }

    public ProductDAO(ServletContext sc) throws ClassNotFoundException, SQLException {
        this.sc = sc;
        con = getConnect(sc);
    }

    private Connection getConnect(ServletContext sc) throws ClassNotFoundException, SQLException {
        ConnectDB connectDB = new ConnectDB(sc);
        return connectDB.getConnection();
    }

    @Override
    public int insertRec(Product obj) {
        int result = 0;
        String sqlString = "INSERT INTO products (productId, productName, productImage, brief, postedDate, typeId, account, unit, price, discount) "
                + "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?);";

        try (PreparedStatement ps = con.prepareStatement(sqlString)) {
            ps.setString(1, obj.getProductId());
            ps.setString(2, obj.getProductName());
            ps.setString(3, obj.getProductImage());
            ps.setString(4, obj.getBrief());
            ps.setDate(5, new java.sql.Date(obj.getPostedDate().getTime()));
            ps.setObject(6, obj.getType() != null ? obj.getType().getTypeId() : null);
            ps.setObject(7, obj.getAccount() != null ? obj.getAccount().getAccount() : null);
            ps.setString(8, obj.getUnit());
            ps.setInt(9, obj.getPrice());
            ps.setInt(10, obj.getDiscount());

            result = ps.executeUpdate();
            con.close();
        } catch (SQLException ex) {
            Logger.getLogger(ProductDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
        return result;
    }

    /**
     * Update information of a product
     */
    @Override
    public int updateRec(Product o) {
        int result = 0;
        String query = "UPDATE products SET productName=?, productImage=?, brief=?, postedDate=?, typeId=?, "
                + "account=?, unit=?, price=?, discount=? WHERE productId=?";
        try (PreparedStatement pstmt = con.prepareStatement(query)) {
            pstmt.setString(1, o.getProductName());
            pstmt.setString(2, o.getProductImage());
            pstmt.setString(3, o.getBrief());
            pstmt.setDate(4, new java.sql.Date(o.getPostedDate().getTime()));
            pstmt.setInt(5, o.getType().getTypeId());
            pstmt.setString(6, o.getAccount().getAccount());
            pstmt.setString(7, o.getUnit());
            pstmt.setInt(8, o.getPrice());
            pstmt.setInt(9, o.getDiscount());
            pstmt.setString(10, o.getProductId());

            result = pstmt.executeUpdate();
        } catch (SQLException ex) {
            Logger.getLogger(ProductDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
        return result;
    }

    /**
     * Remove product from database
     */
    @Override
    public int deleteRec(Product o) {
        int result = 0;
        String query = "DELETE FROM products WHERE productId=?";
        try (PreparedStatement pstmt = con.prepareStatement(query)) {
            pstmt.setString(1, o.getProductId());
            result = pstmt.executeUpdate();
        } catch (SQLException ex) {
            Logger.getLogger(ProductDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
        return result;
    }

    /**
     * Get all products by categoryId
     */
    public List<Product> listByCategory(int categoryId) {
        List<Product> products = new ArrayList<>();
        String query = "SELECT p.*, c.categoryName, c.memo, a.userName, a.email "
                + "FROM products p "
                + "LEFT JOIN categories c ON p.categoryId = c.categoryId "
                + "LEFT JOIN accounts a ON p.accountId = a.accountId "
                + "WHERE p.categoryId = ?";
        try (PreparedStatement pstmt = con.prepareStatement(query)) {
            pstmt.setInt(1, categoryId);
            ResultSet rs = pstmt.executeQuery();
            while (rs.next()) {
                Product product = new Product();
                product.setProductId(rs.getString("productId"));
                product.setProductName(rs.getString("productName"));
                product.setProductImage(rs.getString("productImage"));
                product.setBrief(rs.getString("brief"));
                product.setPostedDate(rs.getDate("postedDate"));
                product.setType(new Category(rs.getInt("categoryId"), "categoryName", "memo"));
                product.setAccount(new Account(
                        rs.getString("account"), // account
                        rs.getString("pass"), // pass
                        rs.getString("lastName"), // lastName
                        rs.getString("firstName"), // firstName
                        rs.getDate("birthday"), // birthday
                        rs.getBoolean("gender"), // gender
                        rs.getString("phone"), // phone
                        rs.getBoolean("isUse"), // isUse
                        rs.getString("roleInSystem") // roleInSystem
                ));
                product.setUnit(rs.getString("unit"));
                product.setPrice(rs.getInt("price"));
                product.setDiscount(rs.getInt("discount"));

                products.add(product);
            }
        } catch (SQLException ex) {
            Logger.getLogger(ProductDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
        return products;
    }

    /**
     * Get all products from database
     */
    @Override
    public List<Product> listAll() {
        List<Product> products = new ArrayList<>();
        String query = "SELECT * FROM products";

        try (Statement stmt = con.createStatement(); ResultSet rs = stmt.executeQuery(query)) {
            AccountDAO ad = new AccountDAO();
            CategoryDAO cd = new CategoryDAO();
            while (rs.next()) {
                products.add(new Product(
                        rs.getString("productId"),
                        rs.getString("productName"),
                        rs.getString("productImage"),
                        rs.getString("brief"),
                        rs.getDate("postedDate"),
                        cd.getObjectById(rs.getString("typeId")),
                        ad.getObjectById(rs.getString("account")),
                        rs.getString("unit"),
                        rs.getInt("price"),
                        rs.getInt("discount"))
                );
            }
        } catch (SQLException ex) {
            Logger.getLogger(ProductDAO.class.getName()).log(Level.SEVERE, null, ex);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(ProductDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
        return products;
    }

    /**
     * Get a product object by Id
     */
    @Override
    public Product getObjectById(String id) {
        Product product = null;
        String query = "SELECT p.ProductID, p.Name, p.Color, p.Price, p.SubcategoryID, psc.Category, p.ModelID, p.Discontinued\n"
                + "FROM [Product] p\n"
                + "INNER JOIN [ProductSubcategory] psc\n"
                + "ON p.SubcategoryID = psc.SubcategoryID\n"
                + "WHERE ProductID = ?";
        try (PreparedStatement pstmt = con.prepareStatement(query)) {
            pstmt.setString(1, id);
            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
                product = new Product();
                product.setProductId(rs.getString("productId"));
                product.setProductName(rs.getString("productName"));
                product.setProductImage(rs.getString("productImage"));
                product.setBrief(rs.getString("brief"));
                product.setPostedDate(rs.getDate("postedDate"));
                product.setType(new Category(rs.getInt("categoryId"), "categoryName", "memo"));
                product.setAccount(new Account(
                        rs.getString("account"), // account
                        rs.getString("pass"), // pass
                        rs.getString("lastName"), // lastName
                        rs.getString("firstName"), // firstName
                        rs.getDate("birthday"), // birthday
                        rs.getBoolean("gender"), // gender
                        rs.getString("phone"), // phone
                        rs.getBoolean("isUse"), // isUse
                        rs.getString("roleInSystem") // roleInSystem
                ));
                product.setUnit(rs.getString("unit"));
                product.setPrice(rs.getInt("price"));
                product.setDiscount(rs.getInt("discount"));
            }
        } catch (SQLException ex) {
            Logger.getLogger(ProductDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
        return product;
    }

    public List<Product> listByName(String productName) {
        List<Product> products = new ArrayList<>();
        String query = "SELECT p.*, c.categoryName, c.memo, a.userName, a.email "
                + "FROM products p "
                + "LEFT JOIN categories c ON p.categoryId = c.categoryId "
                + "LEFT JOIN accounts a ON p.accountId = a.accountId "
                + "WHERE p.productName LIKE ?";
        // Sử dụng LIKE để tìm kiếm tương đối
        try (PreparedStatement pstmt = con.prepareStatement(query)) {
            pstmt.setString(1, "%" + productName + "%"); // Thêm ký tự % để tìm kiếm tương đối
            ResultSet rs = pstmt.executeQuery();
            while (rs.next()) {
                Product product = new Product();
                product.setProductId(rs.getString("productId"));
                product.setProductName(rs.getString("productName"));
                product.setProductImage(rs.getString("productImage"));
                product.setBrief(rs.getString("brief"));
                product.setPostedDate(rs.getDate("postedDate"));
                product.setType(new Category(rs.getInt("categoryId"), "categoryName", "memo")); // Giả sử Category có constructor này
                product.setAccount(new Account(
                        rs.getString("account"), // account
                        rs.getString("pass"), // pass
                        rs.getString("lastName"), // lastName
                        rs.getString("firstName"), // firstName
                        rs.getDate("birthday"), // birthday
                        rs.getBoolean("gender"), // gender
                        rs.getString("phone"), // phone
                        rs.getBoolean("isUse"), // isUse
                        rs.getString("roleInSystem") // roleInSystem
                ));
                product.setUnit(rs.getString("unit"));
                product.setPrice(rs.getInt("price"));
                product.setDiscount(rs.getInt("discount"));

                products.add(product);
            }
        } catch (SQLException ex) {
            Logger.getLogger(ProductDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
        return products;
    }

    public int deleteRec(String productId) {
        int result = 0;
        String query = "DELETE FROM products WHERE productId=?";
        try (PreparedStatement pstmt = con.prepareStatement(query)) {
            pstmt.setString(1, productId);
            result = pstmt.executeUpdate();
        } catch (SQLException ex) {
            Logger.getLogger(ProductDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
        return result;
    }

    public List<Product> listByCategory(String categoryId) throws ClassNotFoundException, SQLException {
        List<Product> list = new ArrayList<>();
        String sql = "SELECT * FROM Products WHERE TypeID = ?";

        try (
                PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, categoryId);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    Product product = new Product();
                    product.setProductId(rs.getString("productId"));
                    product.setProductName(rs.getString("productName"));
                    product.setProductImage(rs.getString("productImage"));
                    product.setBrief(rs.getString("brief"));
                    product.setPostedDate(rs.getDate("postedDate"));
                    product.setType(new Category(rs.getInt("categoryId"), "categoryName", "memo")); // Giả sử Category có constructor này
                    product.setAccount(new Account(
                            rs.getString("account"), // account
                            rs.getString("pass"), // pass
                            rs.getString("lastName"), // lastName
                            rs.getString("firstName"), // firstName
                            rs.getDate("birthday"), // birthday
                            rs.getBoolean("gender"), // gender
                            rs.getString("phone"), // phone
                            rs.getBoolean("isUse"), // isUse
                            rs.getString("roleInSystem") // roleInSystem
                    ));
                    product.setUnit(rs.getString("unit"));
                    product.setPrice(rs.getInt("price"));
                    product.setDiscount(rs.getInt("discount"));

                    list.add(product);
                }
            }
        }

        return list;
    }
}
