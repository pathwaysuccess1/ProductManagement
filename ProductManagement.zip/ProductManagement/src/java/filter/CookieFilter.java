package filter;

import java.io.IOException;
import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebFilter;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import model.Account;
import model.AccountDAO;
import model.SessionDAO;

@WebFilter(urlPatterns = {"/home.jsp", "/index.jsp", "/cart.jsp", "/product.jsp"})
public class CookieFilter implements Filter {
    @Override
    public void init(FilterConfig filterConfig) throws ServletException {
    }
    
    @Override
    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
            throws IOException, ServletException {
        HttpServletRequest req = (HttpServletRequest) request;
        HttpServletResponse res = (HttpServletResponse) response;
        HttpSession session = req.getSession();
        String uri = req.getRequestURI();
        
        // Loại trừ các đường dẫn không cần kiểm tra
        if (uri.endsWith("Login.jsp") || uri.endsWith("LoginSv") || uri.contains("/css/") 
                || uri.contains("/js/") || uri.contains("/images/")) {
            chain.doFilter(request, response);
            return;
        }
        
        // Nếu chưa đăng nhập, kiểm tra cookie
        if (session.getAttribute("login") == null) {
            Cookie[] cookies = req.getCookies();
            String username = null;
            String password = null;
            
            if (cookies != null) {
                for (Cookie cookie : cookies) {
                    if ("username".equals(cookie.getName())) {
                        username = cookie.getValue();
                    } else if ("password".equals(cookie.getName())) {
                        password = cookie.getValue();
                    }
                }
            }
            
            // Nếu có thông tin cookie, kiểm tra đăng nhập
            if (username != null && password != null) {
                try {
                    AccountDAO accountDAO = new AccountDAO();
                    Account account = accountDAO.getObjectById(username);
                    if (account != null && account.getPass().equals(password) && account.isIsUse()) {
                        // Đăng nhập thành công từ cookie
                        session.setAttribute("login", account);
                        // Ghi nhận session mới
                        new SessionDAO().saveAccountSession(account.getAccount(), session.getId());
                    }
                } catch (Exception e) {
                    System.out.println("Lỗi đăng nhập từ cookie: " + e.getMessage());
                }
            }
        }
        
        // Nếu chưa đăng nhập và đang cố gắng truy cập trang chính, chuyển về Login
        if (session.getAttribute("login") == null) {
            System.out.println("CookieFilter: Chuyển hướng đến Login.jsp từ " + uri);
            res.sendRedirect(req.getContextPath() + "/Login.jsp");
            return;
        }
        
        // Cho phép request tiếp tục
        chain.doFilter(request, response);
    }
    
    @Override
    public void destroy() {
    }
}