package filter;

import java.io.IOException;
import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebFilter;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import model.Account;

@WebFilter(urlPatterns = {
    "/admin/*",
    "/AccountController",
    "/CategoryController",
    "/ProductController"
})
public class AuthFilter implements Filter {
    @Override
    public void init(FilterConfig filterConfig) throws ServletException {
        
    }
    
    @Override
    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
            throws IOException, ServletException {
        HttpServletRequest req = (HttpServletRequest) request;
        HttpServletResponse res = (HttpServletResponse) response;
        HttpSession session = req.getSession();
        
        String uri = req.getRequestURI();
        
        // Không lọc các tài nguyên tĩnh và trang đăng nhập
        if (uri.contains("/css/") || uri.contains("/js/") || uri.contains("/images/") 
                || uri.endsWith("Login.jsp") || uri.endsWith("LoginSv")) {
            chain.doFilter(request, response);
            return;
        }
        
        // Kiểm tra xem user đã đăng nhập chưa
        Account account = (Account) session.getAttribute("login");
        
        if (account == null) {
            // Chưa đăng nhập, redirect về trang login
            System.out.println("AuthFilter: Chuyển hướng đến Login.jsp từ " + uri);
            res.sendRedirect(req.getContextPath() + "/Login.jsp");
            return;
        } else {
            // Đã đăng nhập, kiểm tra quyền truy cập
            String role = account.getRoleInSystem();
            
            if (uri.contains("/admin/") && !role.equals("administrator")) {
                // Không phải admin, không cho vào trang admin
                System.out.println("AuthFilter: Chuyển hướng đến home.jsp từ " + uri);
                res.sendRedirect(req.getContextPath() + "/home.jsp");
                return;
            } else {
                // Cho phép đi tiếp
                chain.doFilter(request, response);
            }
        }
    }
    
    @Override
    public void destroy() {
        
    }
}