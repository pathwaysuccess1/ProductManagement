package customTag;

import javax.servlet.jsp.JspException;
import javax.servlet.jsp.JspWriter;
import javax.servlet.jsp.tagext.TagSupport;
import java.io.IOException;

public class PriceFormatTag extends TagSupport {
    private double price;
    private String currencySymbol;
    
    public void setPrice(double price) {
        this.price = price;
    }
    
    public void setCurrencySymbol(String currencySymbol) {
        this.currencySymbol = currencySymbol;
    }
    
    @Override
    public int doStartTag() throws JspException {
        try {
            JspWriter out = pageContext.getOut();
            
            // Định dạng giá tiền
            String formattedPrice = String.format("%,.0f", price);
            
            // Thêm ký hiệu tiền tệ
            if (currencySymbol != null && !currencySymbol.isEmpty()) {
                formattedPrice += " " + currencySymbol;
            } else {
                formattedPrice += " VNĐ";
            }
            
            out.print(formattedPrice);
        } catch (IOException e) {
            throw new JspException("Lỗi khi hiển thị giá: " + e.getMessage());
        }
        
        return SKIP_BODY;
    }
}