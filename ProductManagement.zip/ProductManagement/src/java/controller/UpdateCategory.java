/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import context.Navigation;
import java.io.IOException;
import java.sql.SQLException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import model.Category;
import model.CategoryDAO;

/**
 *
 * @author USER
 */
@WebServlet(name = "UpdateCategoryServlet", urlPatterns = {"/UpdateCategory"})
public class UpdateCategory extends HttpServlet {
  @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            String categoryId = request.getParameter("category");
            Category category = new CategoryDAO().getObjectById(categoryId);
            request.setAttribute("category", category);
            request.getRequestDispatcher(Navigation.UPDATE_CATEGORY).forward(request, response);
        } catch (ClassNotFoundException | SQLException e) {
            throw new ServletException("Error getting category for update", e);
        }
    }
    
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            response.setContentType("text/html;charset=UTF-8");
            request.setCharacterEncoding("UTF-8");
            
            String typeId = request.getParameter("typeId");
            String name = request.getParameter("cateName");
            String memo = request.getParameter("memo");

            CategoryDAO dao = new CategoryDAO();
            
            // If category is already existed, then render message for user
            Category existingCategory = dao.getCateByName(name);
            if (existingCategory != null ) {
                String msg = "Category name is already exist!";
                request.setAttribute("categoryUpdateMsg", msg);
                request.getRequestDispatcher(Navigation.UPDATE_CATEGORY + "?category=" + typeId).forward(request, response);
            } else {
                Category updateCate = dao.getObjectById(typeId);
                updateCate.setCategoryName(name);
                updateCate.setMemo(memo != null ? memo : "");

                int result = dao.updateRec(updateCate);
                response.sendRedirect("ListCategories");
            }
        } catch (ClassNotFoundException | SQLException e) {
            throw new ServletException("Error updating category", e);
        }
    }
}
