/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import context.Navigation;
import java.io.IOException;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import model.Category;
import model.CategoryDAO;

/**
 *
 * @author USER
 */
@WebServlet(name = "AddCategorysv", urlPatterns = {"/AddCategory"})

    public class AddCategorySv extends HttpServlet {

        @Override
        protected void doGet(HttpServletRequest request, HttpServletResponse response)
                throws ServletException, IOException {
            request.getRequestDispatcher(Navigation.ADD_CATEGORY).forward(request, response);
        }

        @Override
        protected void doPost(HttpServletRequest request, HttpServletResponse response)
                throws ServletException, IOException {
            response.setContentType("text/html;charset=UTF-8");
            request.setCharacterEncoding("UTF-8");
            String cateName = request.getParameter("cateName");
            String memo = request.getParameter("memo");
            // Kiểm tra giá trị nhập vào
            if (cateName == null || cateName.trim().isEmpty()) {
                request.setAttribute("categoryMsg", "Category name cannot be empty!");
                request.getRequestDispatcher(Navigation.ADD_CATEGORY).forward(request, response);
                return;
            }
            CategoryDAO dao = null;
            try {
                dao = new CategoryDAO();
            } catch (ClassNotFoundException ex) {
                Logger.getLogger(AddCategorySv.class.getName()).log(Level.SEVERE, null, ex);
            } catch (SQLException ex) {
                Logger.getLogger(AddCategorySv.class.getName()).log(Level.SEVERE, null, ex);
            }
            // Kiểm tra xem danh mục đã tồn tại chưa
            Category existingCategory = dao.getCateByName(cateName);
            if (existingCategory != null) {
                request.setAttribute("categoryMsg", "Category name already exists!");
                request.getRequestDispatcher(Navigation.ADD_CATEGORY).forward(request, response);
                return;
            }
            // Tạo mới Category và thêm vào database
            Category c = new Category();
            c.setCategoryName(cateName);
            c.setMemo(memo);
            int rowsInserted = dao.insertRec(c);
            if (rowsInserted > 0) {
                System.out.println("Inserted category: " + cateName);
                response.sendRedirect("CategoryList");
            } else {
                request.setAttribute("categoryMsg", "Failed to add category. Please try again.");
                request.getRequestDispatcher(Navigation.ADD_CATEGORY).forward(request, response);
            }
        }
    }
