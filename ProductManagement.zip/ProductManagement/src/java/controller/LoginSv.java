package controller;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import model.Account;
import context.Navigation;
import utils.ConnectDB;

/**
 * Servlet implementation class LoginSv
 */
public class LoginSv extends HttpServlet {
    private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public LoginSv() {
        super();
    }

    /**
     * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
     */
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Forward to login page when accessed via GET
        request.getRequestDispatcher("Login.jsp").forward(request, response);
    }

    /**
     * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
     */
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Get parameters from login form
        String username = request.getParameter("account");
        String password = request.getParameter("pass");
        
        // Check if parameters exist
        if (username == null || password == null || username.trim().isEmpty() || password.trim().isEmpty()) {
            request.setAttribute("ERROR", "Username and password are required");
            request.getRequestDispatcher("Login.jsp").forward(request, response);
            return;
        }
        
        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        
        try {
            // Establish database connection
            ConnectDB db = new ConnectDB();
            conn = db.getConnection();
            
            // Create SQL query to verify user credentials
            String sql = "SELECT * FROM accounts WHERE account = ? AND pass = ?";
            ps = conn.prepareStatement(sql);
            ps.setString(1, username);
            ps.setString(2, password);
            
            rs = ps.executeQuery();
            
            if (rs.next()) {
                // User authenticated successfully
                Account loggedInUser = new Account();
                loggedInUser.setAccount(rs.getString("account"));
                loggedInUser.setFirstName(rs.getString("firstName"));
                loggedInUser.setLastName(rs.getString("lastName"));
                loggedInUser.setRoleInSystem(rs.getString("roleInSystem"));
                
                // Store user in session
                HttpSession session = request.getSession();
                session.setAttribute("login", loggedInUser);
                
                // Redirect to dashboard
                response.sendRedirect(Navigation.MAIN_DASHBOARD);
            } else {
                // Authentication failed
                request.setAttribute("ERROR", "Invalid username or password");
                request.getRequestDispatcher("Login.jsp").forward(request, response);
            }
            
        } catch (Exception e) {
            // Log the error for debugging
            e.printStackTrace();
            
            // Handle database errors
            request.setAttribute("ERROR", "Database error: " + e.getMessage());
            request.getRequestDispatcher("Login.jsp").forward(request, response);
        } finally {
            // Close resources
            try {
                if (rs != null) rs.close();
                if (ps != null) ps.close();
                if (conn != null) conn.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }
}