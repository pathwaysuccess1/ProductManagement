package controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import model.Product;
import model.ProductDAO;

@WebServlet(name = "SearchProductServlet", urlPatterns = {"/SearchProductServlet"})
public class SearchProductServlet extends HttpServlet {

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        request.setCharacterEncoding("UTF-8");
        
        try {
            String searchType = request.getParameter("searchType");
            String searchValue = request.getParameter("searchValue");
            String categoryId = request.getParameter("categoryId");
            String minPrice = request.getParameter("minPrice");
            String maxPrice = request.getParameter("maxPrice");
            String sortBy = request.getParameter("sortBy");
            String sortOrder = request.getParameter("sortOrder");
            
            ProductDAO productDAO = new ProductDAO();
            List<Product> products = new ArrayList<>();
            
            // Tìm kiếm cơ bản
            if (searchType == null || searchValue == null || searchValue.trim().isEmpty()) {
                // Nếu không có điều kiện tìm kiếm, lấy tất cả sản phẩm
                products = productDAO.getAllObjects();
            } else {
                // Tìm kiếm theo loại
                switch (searchType) {
                    case "id":
                        try {
                            int id = Integer.parseInt(searchValue);
                            Product product = productDAO.getObjectById(id);
                            if (product != null) {
                                products.add(product);
                            }
                        } catch (NumberFormatException e) {
                            request.setAttribute("errorMessage", "ID sản phẩm phải là số!");
                        }
                        break;
                    case "name":
                        products = productDAO.searchByName(searchValue);
                        break;
                    case "description":
                        products = productDAO.searchByDescription(searchValue);
                        break;
                    default:
                        products = productDAO.getAllObjects();
                        break;
                }
            }
            
            // Lọc thêm theo danh mục
            if (categoryId != null && !categoryId.trim().isEmpty()) {
                try {
                    int catId = Integer.parseInt(categoryId);
                    List<Product> filteredProducts = new ArrayList<>();
                    for (Product product : products) {
                        if (product.getCategoryId() == catId) {
                            filteredProducts.add(product);
                        }
                    }
                    products = filteredProducts;
                } catch (NumberFormatException e) {
                    request.setAttribute("errorMessage", "ID danh mục phải là số!");
                }
            }
            
            // Lọc theo khoảng giá
            if (minPrice != null && !minPrice.trim().isEmpty() && maxPrice != null && !maxPrice.trim().isEmpty()) {
                try {
                    double min = Double.parseDouble(minPrice);
                    double max = Double.parseDouble(maxPrice);
                    List<Product> filteredProducts = new ArrayList<>();
                    for (Product product : products) {
                        if (product.getPrice() >= min && product.getPrice() <= max) {
                            filteredProducts.add(product);
                        }
                    }
                    products = filteredProducts;
                } catch (NumberFormatException e) {
                    request.setAttribute("errorMessage", "Giá phải là số!");
                }
            }
            
            // Sắp xếp kết quả
            if (sortBy != null && !sortBy.trim().isEmpty()) {
                boolean isAsc = sortOrder == null || "asc".equalsIgnoreCase(sortOrder);
                switch (sortBy) {
                    case "price":
                        products.sort((p1, p2) -> {
                            return isAsc ? 
                                    Double.compare(p1.getPrice(), p2.getPrice()) : 
                                    Double.compare(p2.getPrice(), p1.getPrice());
                        });
                        break;
                    case "name":
                        products.sort((p1, p2) -> {
                            return isAsc ? 
                                    p1.getName().compareTo(p2.getName()) : 
                                    p2.getName().compareTo(p1.getName());
                        });
                        break;
                    case "views":