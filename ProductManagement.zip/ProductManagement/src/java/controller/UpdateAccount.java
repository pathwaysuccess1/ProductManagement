package controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import model.Account;
import model.AccountDAO;

@WebServlet(name = "UpdateAccount", urlPatterns = {"/UpdateAccount"})
public class UpdateAccount extends HttpServlet {
    
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        request.setCharacterEncoding("UTF-8");
        
        try {
            // Lấy thông tin account từ form
            String username = request.getParameter("username");
            String password = request.getParameter("password");
            String fullName = request.getParameter("fullName");
            String email = request.getParameter("email");
            String phone = request.getParameter("phone");
            String address = request.getParameter("address");
            String role = request.getParameter("role");
            boolean isUse = request.getParameter("isUse") != null;
            
            // Kiểm tra xem account có tồn tại không
            AccountDAO accountDAO = new AccountDAO();
            Account account = accountDAO.getObjectById(username);
            
            if (account != null) {
                // Cập nhật thông tin account
                account.setPass(password);
                account.setName(fullName);
                account.setEmail(email);
                account.setPhone(phone);
                account.setAddress(address);
                account.setRoleInSystem(role);
                account.setIsUse(isUse);
                
                // Lưu vào database
                boolean updated = accountDAO.update(account);
                
                if (updated) {
                    request.setAttribute("successMessage", "Cập nhật tài khoản thành công!");
                } else {
                    request.setAttribute("errorMessage", "Cập nhật tài khoản thất bại!");
                }
            } else {
                request.setAttribute("errorMessage", "Không tìm thấy tài khoản!");
            }
            
            // Chuyển hướng về trang quản lý tài khoản
            request.getRequestDispatcher("/admin/account-management.jsp").forward(request, response);
            
        } catch (Exception e) {
            System.out.println("Error in UpdateAccountServlet: " + e.getMessage());
            request.setAttribute("errorMessage", "Đã xảy ra lỗi: " + e.getMessage());
            request.getRequestDispatcher("/error.jsp").forward(request, response);
        }
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        // Lấy thông tin account cần cập nhật
        String username = request.getParameter("username");
        
        try {
            AccountDAO accountDAO = new AccountDAO();
            Account account = accountDAO.getObjectById(username);
            
            if (account != null) {
                request.setAttribute("account", account);
                request.getRequestDispatcher("/admin/update-account.jsp").forward(request, response);
            } else {
                request.setAttribute("errorMessage", "Không tìm thấy tài khoản!");
                request.getRequestDispatcher("/admin/account-management.jsp").forward(request, response);
            }
        } catch (Exception e) {
            System.out.println("Error in UpdateAccountServlet (doGet): " + e.getMessage());
            request.setAttribute("errorMessage", "Đã xảy ra lỗi: " + e.getMessage());
            request.getRequestDispatcher("/error.jsp").forward(request, response);
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    @Override
    public String getServletInfo() {
        return "Servlet để cập nhật thông tin tài khoản";
    }
}