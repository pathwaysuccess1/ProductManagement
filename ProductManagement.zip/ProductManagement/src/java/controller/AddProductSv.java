package controller;

import java.io.IOException;
import java.sql.Date;
import java.sql.SQLException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import model.AccountDAO;
import model.CategoryDAO;
import model.ProductDAO;
import model.Product;
import context.Navigation;
import context.Action;
import java.time.LocalDate;
import java.util.logging.Level;
import java.util.logging.Logger;

@WebServlet("/AddProduct")
public class AddProductSv extends HttpServlet {

    private static final long serialVersionUID = 1L;

    public AddProductSv() {
        super();
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            request.setAttribute("categories", new CategoryDAO().listAll());
            request.getRequestDispatcher(Navigation.ADD_PRODUCT).forward(request, response);
        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
            request.setAttribute("errorMsg", "Error loading categories: " + e.getMessage());
            request.getRequestDispatcher(Navigation.ADD_PRODUCT).forward(request, response);
        }
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String productId = request.getParameter("productId");
        String productName = request.getParameter("productName");
        String brief = request.getParameter("brief");
        String unit = request.getParameter("unit");
        String type = request.getParameter("typeId");
        String account = request.getParameter("account");
        int price = Integer.parseInt(request.getParameter("price"));
        int discount = Integer.parseInt(request.getParameter("discount"));
        String image = request.getParameter("productImagePath");
        AccountDAO ad = null;
        try {
            ad = new AccountDAO();
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(AddProductSv.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SQLException ex) {
            Logger.getLogger(AddProductSv.class.getName()).log(Level.SEVERE, null, ex);
        }
        CategoryDAO cd = null;
        try {
            cd = new CategoryDAO();
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(AddProductSv.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SQLException ex) {
            Logger.getLogger(AddProductSv.class.getName()).log(Level.SEVERE, null, ex);
        }
        Product product = new Product();
        product.setProductId(productId);
        product.setProductName(productName);
        product.setProductImage(image);
        product.setBrief(brief);
        product.setUnit(unit);
        product.setPrice(price);
        product.setDiscount(discount);
        product.setPostedDate(Date.valueOf(LocalDate.now()));
        product.setType(cd.getObjectById(type));
        product.setAccount(ad.getObjectById(account));
        ProductDAO pd = null;
        try {
            pd = new ProductDAO();
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(AddProductSv.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SQLException ex) {
            Logger.getLogger(AddProductSv.class.getName()).log(Level.SEVERE, null, ex);
        }
        int rs = pd.insertRec(product);
        if (rs == 0) {
            request.getSession().setAttribute("errorMessage", "Error : Add unssuccessfull!" + product.toString());
        } else {
            request.getSession().setAttribute("successMessage", "Add successful!");
        }
        response.sendRedirect("productlist?action=" + Action.LIST_PRODUCT);
    }
}
