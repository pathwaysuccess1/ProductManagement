/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import context.Action;
import context.Navigation;
import java.io.IOException;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import model.Account;
import model.Category;
import model.CategoryDAO;
import model.Product;
import model.ProductDAO;

/**
 *
 * @author USER
 */
@WebServlet(name = "UpdateProductServlet", urlPatterns = {"/UpdateProduct"})
public class UpdateProduct extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            String productId = request.getParameter("product");
            Product product = new ProductDAO().getObjectById(productId);
            request.setAttribute("product", product);

            // Load categories for dropdown
            CategoryDAO categoryDAO = new CategoryDAO();
            request.setAttribute("categories", categoryDAO.listAll());

            request.getRequestDispatcher(Navigation.UPDATE_PRODUCT).forward(request, response);
        } catch (ClassNotFoundException | SQLException e) {
            throw new ServletException("Error getting product for update", e);
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        response.setContentType("text/html;charset=UTF-8");
        request.setCharacterEncoding("UTF-8");

        HttpSession session = request.getSession();
        Account account = (Account) session.getAttribute("login");

        String productId = request.getParameter("id");
        String productName = request.getParameter("name");
        String brief = request.getParameter("brief");
        String unit = request.getParameter("unit");
        String price = request.getParameter("price");
        String discount = request.getParameter("discount");
        String typeId = request.getParameter("type");

        // Process Date by TimeStamp
        Timestamp postedDate = new Timestamp(System.currentTimeMillis());

        CategoryDAO cateDao = null;
        try {
            cateDao = new CategoryDAO();
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(UpdateProduct.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SQLException ex) {
            Logger.getLogger(UpdateProduct.class.getName()).log(Level.SEVERE, null, ex);
        }
        Category type = cateDao.getObjectById(typeId);

        // Set all product attributes
        Product product = new Product();
        ProductDAO dao = null;
        try {
            dao = new ProductDAO();
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(UpdateProduct.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SQLException ex) {
            Logger.getLogger(UpdateProduct.class.getName()).log(Level.SEVERE, null, ex);
        }
        product.setProductId(productId);
        product.setProductName(productName);
        product.setBrief(brief != null ? brief : "");
        product.setPostedDate(postedDate);
        product.setType(type);
        product.setAccount(account);
        product.setUnit(unit != null ? unit : "");
        product.setPrice(price != null ? Integer.parseInt(price) : 0);
        product.setDiscount(discount != null ? Integer.parseInt(discount) : 0);

        int rs = dao.updateRec(product);
        if (rs == 0) {
            request.getSession().setAttribute("errorMessage", "Error : Add unssuccessfull!" + product.toString());
        } else {
            request.getSession().setAttribute("successMessage", "Add successful!");
        }

        response.sendRedirect("productlist?action=" + Action.LIST_PRODUCT);
    }
}
