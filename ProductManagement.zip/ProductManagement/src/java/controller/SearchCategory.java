package controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import model.Category;
import model.CategoryDAO;

@WebServlet(name = "SearchCategoryServlet", urlPatterns = {"/SearchCategoryServlet"})
public class SearchCategoryServlet extends HttpServlet {

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        request.setCharacterEncoding("UTF-8");
        
        try {
            String searchType = request.getParameter("searchType");
            String searchValue = request.getParameter("searchValue");
            
            CategoryDAO categoryDAO = new CategoryDAO();
            List<Category> categories = new ArrayList<>();
            
            if (searchType == null || searchValue == null || searchValue.trim().isEmpty()) {
                // Nếu không có điều kiện tìm kiếm, lấy tất cả danh mục
                categories = categoryDAO.getAllObjects();
            } else {
                // Tìm kiếm theo loại
                switch (searchType) {
                    case "id":
                        try {
                            int id = Integer.parseInt(searchValue);
                            Category category = categoryDAO.getObjectById(id);
                            if (category != null) {
                                categories.add(category);
                            }
                        } catch (NumberFormatException e) {
                            request.setAttribute("errorMessage", "ID danh mục phải là số!");
                        }
                        break;
                    case "name":
                        categories = categoryDAO.searchByName(searchValue);
                        break;
                    case "status":
                        boolean status = Boolean.parseBoolean(searchValue);
                        categories = categoryDAO.searchByStatus(status);
                        break;
                    default:
                        categories = categoryDAO.getAllObjects();
                        break;
                }
            }
            
            request.setAttribute("categories", categories);
            request.setAttribute("searchType", searchType);
            request.setAttribute("searchValue", searchValue);
            
            request.getRequestDispatcher("/admin/category-management.jsp").forward(request, response);
            
        } catch (Exception e) {
            System.out.println("Error in SearchCategoryServlet: " + e.getMessage());
            request.setAttribute("errorMessage", "Đã xảy ra lỗi: " + e.getMessage());
            request.getRequestDispatcher("/error.jsp").forward(request, response);
        }
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    @Override
    public String getServletInfo() {
        return "Servlet để tìm kiếm danh mục";
    }
}