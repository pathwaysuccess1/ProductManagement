/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import context.Navigation;
import java.io.IOException;
import java.sql.SQLException;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import model.Category;
import model.CategoryDAO;

/**
 *
 * @author USER
 */
public class CategoryList extends HttpServlet {

   @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            response.setContentType("text/html;charset=UTF-8");
            request.setCharacterEncoding("UTF-8");

            CategoryDAO dao = new CategoryDAO();
            List<Category> list = dao.listAll();
            
            if (list == null) {
                System.out.println("listAll() trả về null");
            } else {
                System.out.println("List Size: " + list.size());
                for (Category cate : list) {
                    System.out.println("Category: " + cate.getCategoryName());
                }
            }
            
            request.setAttribute("listCategory", list);
            request.getRequestDispatcher(Navigation.LIST_CATEGORY).forward(request, response);
        } catch (ClassNotFoundException | SQLException e) {
            throw new ServletException("Error listing categories", e);
        }
    }
}
