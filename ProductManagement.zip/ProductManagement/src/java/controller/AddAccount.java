package controller;
import java.io.IOException;
import java.sql.Date;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import model.AccountDAO;
import model.Account;
import context.Action;
import context.Navigation;

/**
 * Servlet implementation class AddAccountServlet
 * Handles the creation of new user accounts
 */
@WebServlet("/AddAccountServlet")
public class AddAccount extends HttpServlet {
    private static final long serialVersionUID = 1L;
       
    /**
     * Constructor for AddAccountServlet
     */
    public AddAccount() {
        super();
    }

    /**
     * Handle GET requests - displays the account creation form
     */
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        request.getRequestDispatcher(Navigation.ADD_ACCOUNT).forward(request, response);
    }

    /**
     * Handle POST requests - processes form submission to create a new account
     */
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            addAccount(request, response);
        } catch (ClassNotFoundException | SQLException e) {
            // Log error
            e.printStackTrace();
            
            // Display error message to user
            request.setAttribute("errorMsg", "Database error occurred: " + e.getMessage());
            request.getRequestDispatcher(Navigation.ADD_ACCOUNT).forward(request, response);
        }
    }
    
    /**
     * Process data from the form and create a new account
     */
    private void addAccount(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException, ClassNotFoundException, SQLException {
        response.setContentType("text/html;charset=UTF-8");
        request.setCharacterEncoding("UTF-8");
        
        // Extract form parameters
        String account = request.getParameter("account");
        String pass = request.getParameter("pass");
        String lastName = request.getParameter("lastName");
        String firstName = request.getParameter("firstName");
        String ns = request.getParameter("birthday");
        Date birthday = Date.valueOf(ns);
        boolean gender = (request.getParameter("gender").equals("1"));
        String phone = request.getParameter("phone");
        boolean isUse = (request.getParameter("isUse") != null);
        String roleInSystem = request.getParameter("roleinSystem");
        
        // Check if account already exists
        if (new AccountDAO().getObjectById(account) != null) {
            String msg = "Account is already exist!";
            request.setAttribute("accountMsg", msg);
            request.getRequestDispatcher(Navigation.ADD_ACCOUNT).forward(request, response);
        } else {
            // Create new account and insert into database
            Account acc = new Account(account, pass, lastName, firstName, birthday, gender, phone, isUse, roleInSystem);
            int result = new AccountDAO().insertRec(acc);
            
            // Redirect to account list
            response.sendRedirect("AddAccount?action=" + Action.LIST_ACCOUNT);
        }
    }
}