package controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import model.Account;
import model.AccountDAO;

@WebServlet(name = "SearchAccount", urlPatterns = {"/SearchAccount"})
public class SearchAccount extends HttpServlet {

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        request.setCharacterEncoding("UTF-8");
        
        try {
            String searchType = request.getParameter("searchType");
            String searchValue = request.getParameter("searchValue");
            
            AccountDAO accountDAO = new AccountDAO();
            List<Account> accounts = new ArrayList<>();
            
            if (searchType == null || searchValue == null || searchValue.trim().isEmpty()) {
                // Nếu không có điều kiện tìm kiếm, lấy tất cả tài khoản
                accounts = accountDAO.getAllObjects();
            } else {
                // Tìm kiếm theo loại
                switch (searchType) {
                    case "username":
                        Account account = accountDAO.getObjectById(searchValue);
                        if (account != null) {
                            accounts.add(account);
                        }
                        break;
                    case "name":
                        accounts = accountDAO.searchByName(searchValue);
                        break;
                    case "email":
                        accounts = accountDAO.searchByEmail(searchValue);
                        break;
                    case "role":
                        accounts = accountDAO.searchByRole(searchValue);
                        break;
                    default:
                        accounts = accountDAO.getAllObjects();
                        break;
                }
            }
            
            request.setAttribute("accounts", accounts);
            request.setAttribute("searchType", searchType);
            request.setAttribute("searchValue", searchValue);
            
            request.getRequestDispatcher("/admin/account-management.jsp").forward(request, response);
            
        } catch (Exception e) {
            System.out.println("Error in SearchAccountServlet: " + e.getMessage());
            request.setAttribute("errorMessage", "Đã xảy ra lỗi: " + e.getMessage());
            request.getRequestDispatcher("/error.jsp").forward(request, response);
        }
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    @Override
    public String getServletInfo() {
        return "Servlet để tìm kiếm tài khoản";
    }
}